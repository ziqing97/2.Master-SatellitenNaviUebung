close all;
clear;
clc;

% Autor: Carsten Helfert

%% StaNav Übung 1

addpath(genpath('Daten/'));
data = readtable('Base_Alloy_1Hz.txt');
data2 = readtable('Base_Alloy2_1Hz.txt');
%data = readtable('Icare_NetR9_1Hz.txt');
data(1:14,:) = [];
time = table2array(data(:,2));
time2 = table2array(data2(:,6));
data = table2array(data(:,3:end));
data2 = table2array(data2(:,7:end));

data3 = zeros(length(data2)-2,3);
for i=0:length(data3)-1
    data3(i+1,:) = data(i*30+1,1:3);
end
data2(36:37,:) = [];
time2(36:37,:) = [];

lat1 = data3(:,1);
lon1 = data3(:,2);
lat2 = data2(:,11) + data2(:,12) / 60 + data2(:,13) / 3600;
lon2 = data2(:,14) + data2(:,15) / 60 + data2(:,16) / 3600;

dlat = (lat1-lat2)*pi*6371000*2/360;

h1 = data3(:,3);
h2 = data2(:,17);

figure;
subplot(3,1,1);
title('Vergleich beider Auswertungen');
hold on
plot(time2, lat1, '-')
plot(time2, lat2, '-')
ylabel('Breite [°]')
legend('Auswertung RTKLIB','CSRS-PPP des NRC','Location','east')
grid on
subplot(3,1,2);
hold on
plot(time2, lon1, '-')
plot(time2, lon2, '-')
ylabel('Länge [°]','interpreter','Latex')
grid on
subplot(3,1,3);
hold on
plot(time2, h1, '-')
plot(time2, h2, '-')
xlabel('Zeit','interpreter','Latex')
ylabel('Höhe [m]','interpreter','Latex')
grid on

delta_lon = (lon1 - lon2) * pi * 6371000 / 180;     % Längendiff
delta_lat = (lat1 - lat2) * pi * 6371000 / 180;     % Breitendiff
delta_h = h1 - h2;

figure;
subplot(3,1,1);
title('Vergleich beider Auswertungen');
hold on
plot(time2, delta_lon, '-')
ylabel('\Delta Breite [m]')
legend('Auswertung RTKLIB','CSRS-PPP des NRC','Location','east')
grid on
subplot(3,1,2);
hold on
plot(time2, delta_lat, '-')
ylabel('\Delta Länge [m]')
grid on
subplot(3,1,3);
hold on
plot(time2, delta_h, '-')
ylabel('\Delta h [m]')
xlabel('Zeit','interpreter','Latex')
grid on

%std = sqrt(data(:,6).^2+data(:,7).^2+data(:,8).^2);
%std2 = sqrt(data2(:,6).^2+data2(:,7).^2+data2(:,8).^2);

% figure
% plot(time,std)
% xlabel('Time','interpreter','Latex')
% ylabel('Standardabweichung [m]','interpreter','Latex')
% title('Standardabweichung der Position','interpreter','Latex')
% grid on
% 
% figure
% subplot(3,1,1);
% plot(time,data(:,6))
% title('Standardabweichung North','interpreter','Latex')
% subplot(3,1,2); 
% plot(time,data(:,7))
% title('Standardabweichung East','interpreter','Latex')
% subplot(3,1,3); 
% plot(time,data(:,8))
% title('Standardabweichung Up','interpreter','Latex')


